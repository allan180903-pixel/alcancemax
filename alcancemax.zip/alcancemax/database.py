import sqlite3
import pandas as pd
from datetime import datetime
import os

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Caminho do banco ativo — definido por set_user() após o login
_DB_PATH = os.path.join(_BASE_DIR, "dados", "prospeccao.db")
_USER_CONFIG_PATH = os.path.join(_BASE_DIR, "config.json")


def _email_to_folder(email: str) -> str:
    """Converte e-mail em nome de pasta seguro."""
    return email.lower().replace("@", "_at_").replace(".", "_").replace("+", "_")


def set_user(email: str):
    """Define os caminhos do banco e config para o usuário logado."""
    global _DB_PATH, _USER_CONFIG_PATH
    folder = os.path.join(_BASE_DIR, "dados", "users", _email_to_folder(email))
    os.makedirs(folder, exist_ok=True)
    _DB_PATH = os.path.join(folder, "leads.db")
    _USER_CONFIG_PATH = os.path.join(folder, "config.json")


def get_user_config_path() -> str:
    return _USER_CONFIG_PATH


def get_connection():
    os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
    return sqlite3.connect(_DB_PATH)


def init_db():
    conn = get_connection()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS leads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        empresa TEXT,
        email TEXT,
        whatsapp TEXT,
        cidade TEXT,
        segmento TEXT,
        status TEXT DEFAULT 'Novo',
        data_criacao TEXT,
        notas TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS envios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lead_id INTEGER,
        tipo TEXT,
        status TEXT DEFAULT 'Enviado',
        data_envio TEXT,
        template_nome TEXT,
        FOREIGN KEY (lead_id) REFERENCES leads(id)
    )''')
    conn.commit()
    conn.close()


def add_lead(nome, empresa, email, whatsapp, cidade, segmento, notas=""):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        '''INSERT INTO leads (nome, empresa, email, whatsapp, cidade, segmento, data_criacao, notas)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
        (nome, empresa, email, whatsapp, cidade, segmento,
         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), notas)
    )
    conn.commit()
    lead_id = c.lastrowid
    conn.close()
    return lead_id


def get_all_leads():
    conn = get_connection()
    df = pd.read_sql_query("SELECT * FROM leads ORDER BY data_criacao DESC", conn)
    conn.close()
    return df


def get_lead_by_id(lead_id):
    conn = get_connection()
    df = pd.read_sql_query("SELECT * FROM leads WHERE id = ?", conn, params=(lead_id,))
    conn.close()
    return df.iloc[0] if not df.empty else None


def update_lead(lead_id, nome, empresa, email, whatsapp, cidade, segmento, status, notas):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        '''UPDATE leads SET nome=?, empresa=?, email=?, whatsapp=?, cidade=?,
           segmento=?, status=?, notas=? WHERE id=?''',
        (nome, empresa, email, whatsapp, cidade, segmento, status, notas, lead_id)
    )
    conn.commit()
    conn.close()


def update_lead_status(lead_id, status):
    conn = get_connection()
    c = conn.cursor()
    c.execute("UPDATE leads SET status = ? WHERE id = ?", (status, lead_id))
    conn.commit()
    conn.close()


def delete_lead(lead_id):
    conn = get_connection()
    c = conn.cursor()
    c.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    c.execute("DELETE FROM envios WHERE lead_id = ?", (lead_id,))
    conn.commit()
    conn.close()


def log_envio(lead_id, tipo, template_nome):
    conn = get_connection()
    c = conn.cursor()
    c.execute(
        '''INSERT INTO envios (lead_id, tipo, data_envio, template_nome)
           VALUES (?, ?, ?, ?)''',
        (lead_id, tipo, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), template_nome)
    )
    conn.commit()
    conn.close()


def get_stats():
    conn = get_connection()
    stats = {}

    stats['total_leads'] = pd.read_sql_query(
        "SELECT COUNT(*) as c FROM leads", conn)['c'][0]

    stats['por_status'] = pd.read_sql_query(
        "SELECT status, COUNT(*) as count FROM leads GROUP BY status ORDER BY count DESC", conn)

    stats['emails_semana'] = pd.read_sql_query(
        "SELECT COUNT(*) as c FROM envios WHERE tipo='email' AND data_envio >= date('now', '-7 days')",
        conn)['c'][0]

    stats['whatsapp_semana'] = pd.read_sql_query(
        "SELECT COUNT(*) as c FROM envios WHERE tipo='whatsapp' AND data_envio >= date('now', '-7 days')",
        conn)['c'][0]

    stats['total_emails'] = pd.read_sql_query(
        "SELECT COUNT(*) as c FROM envios WHERE tipo='email'", conn)['c'][0]

    stats['total_whatsapp'] = pd.read_sql_query(
        "SELECT COUNT(*) as c FROM envios WHERE tipo='whatsapp'", conn)['c'][0]

    stats['atividade_diaria'] = pd.read_sql_query(
        '''SELECT date(data_envio) as data, tipo, COUNT(*) as total
           FROM envios
           WHERE data_envio >= date('now', '-30 days')
           GROUP BY date(data_envio), tipo
           ORDER BY data''', conn)

    stats['leads_por_segmento'] = pd.read_sql_query(
        "SELECT segmento, COUNT(*) as count FROM leads WHERE segmento != '' GROUP BY segmento ORDER BY count DESC",
        conn)

    conn.close()
    return stats


def import_leads_from_df(df_import):
    conn = get_connection()
    c = conn.cursor()
    imported = 0
    skipped = 0

    col_map = {
        'nome': ['nome', 'Nome', 'NOME', 'name', 'Name'],
        'empresa': ['empresa', 'Empresa', 'EMPRESA', 'company', 'Company'],
        'email': ['email', 'Email', 'EMAIL', 'e-mail', 'E-mail'],
        'whatsapp': ['whatsapp', 'WhatsApp', 'WHATSAPP', 'telefone', 'Telefone', 'phone', 'celular', 'Celular'],
        'cidade': ['cidade', 'Cidade', 'CIDADE', 'city', 'City'],
        'segmento': ['segmento', 'Segmento', 'SEGMENTO', 'segment', 'categoria', 'Categoria'],
        'notas': ['notas', 'Notas', 'NOTAS', 'observacoes', 'Observações', 'notes'],
    }

    def find_col(field):
        for candidate in col_map[field]:
            if candidate in df_import.columns:
                return candidate
        return None

    nome_col = find_col('nome')
    if not nome_col:
        return 0, len(df_import)

    for _, row in df_import.iterrows():
        try:
            nome = str(row.get(nome_col, '')).strip()
            if not nome or nome == 'nan':
                skipped += 1
                continue

            def get(field):
                col = find_col(field)
                val = str(row.get(col, '')) if col else ''
                return '' if val == 'nan' else val.strip()

            c.execute(
                '''INSERT INTO leads (nome, empresa, email, whatsapp, cidade, segmento, data_criacao, notas)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                (nome, get('empresa'), get('email'), get('whatsapp'),
                 get('cidade'), get('segmento'),
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S"), get('notas'))
            )
            imported += 1
        except Exception:
            skipped += 1

    conn.commit()
    conn.close()
    return imported, skipped


def get_envios_for_lead(lead_id):
    conn = get_connection()
    df = pd.read_sql_query(
        "SELECT * FROM envios WHERE lead_id = ? ORDER BY data_envio DESC", conn,
        params=(lead_id,))
    conn.close()
    return df


import json as _json

_DEFAULT_STATUS   = ["Novo", "Email Enviado", "WhatsApp Enviado", "Contatado",
                     "Respondeu", "Reunião Agendada", "Fechado", "Sem Interesse"]
_DEFAULT_SEGMENTOS = ["Arquiteto", "Designer de Interiores", "Construtora",
                      "Incorporadora", "Loja de Móveis", "Decorador", "Outro"]


def get_status_options():
    try:
        with open(_USER_CONFIG_PATH, 'r', encoding='utf-8') as f:
            return _json.load(f).get('filtros', {}).get('status', []) or _DEFAULT_STATUS
    except Exception:
        return _DEFAULT_STATUS


def get_segmento_options():
    try:
        with open(_USER_CONFIG_PATH, 'r', encoding='utf-8') as f:
            return _json.load(f).get('filtros', {}).get('segmentos', []) or _DEFAULT_SEGMENTOS
    except Exception:
        return _DEFAULT_SEGMENTOS


STATUS_OPTIONS   = _DEFAULT_STATUS
SEGMENTO_OPTIONS = _DEFAULT_SEGMENTOS
