import sqlite3
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, Reference
from datetime import datetime
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dados", "prospeccao.db")
REPORTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "relatorios")

# Styles
BLUE_DARK = "1B3A5C"
BLUE_MID = "2D6A9F"
GREEN = "27AE60"
ORANGE = "E67E22"
RED = "E74C3C"
GRAY_LIGHT = "F5F6FA"
WHITE = "FFFFFF"
GRAY_BORDER = "DDDDDD"


def _header_style(cell, bg=BLUE_DARK):
    cell.font = Font(name="Arial", bold=True, color=WHITE, size=10)
    cell.fill = PatternFill("solid", fgColor=bg)
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = _thin_border()


def _thin_border(color=GRAY_BORDER):
    s = Side(style="thin", color=color)
    return Border(left=s, right=s, top=s, bottom=s)


def _data_cell(cell, value, bold=False, center=False, color=None):
    cell.value = value
    cell.font = Font(name="Arial", size=10, bold=bold, color=color or "333333")
    cell.alignment = Alignment(horizontal="center" if center else "left", vertical="center")
    cell.border = _thin_border()


def _kpi_block(ws, row, col, label, value, color, unit=""):
    label_cell = ws.cell(row=row, column=col, value=label)
    label_cell.font = Font(name="Arial", bold=True, size=9, color=WHITE)
    label_cell.fill = PatternFill("solid", fgColor=color)
    label_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    val_cell = ws.cell(row=row + 1, column=col, value=f"{value}{unit}")
    val_cell.font = Font(name="Arial", bold=True, size=22, color=color)
    val_cell.alignment = Alignment(horizontal="center", vertical="center")
    val_cell.fill = PatternFill("solid", fgColor="F8F9FA")


def get_report_data(days=7):
    if not os.path.exists(DB_PATH):
        return None

    conn = sqlite3.connect(DB_PATH)
    data = {}

    data['total_leads'] = pd.read_sql_query("SELECT COUNT(*) as c FROM leads", conn)['c'][0]
    data['por_status'] = pd.read_sql_query(
        "SELECT status, COUNT(*) as count FROM leads GROUP BY status ORDER BY count DESC", conn)
    data['por_segmento'] = pd.read_sql_query(
        "SELECT segmento, COUNT(*) as count FROM leads WHERE segmento != '' GROUP BY segmento ORDER BY count DESC",
        conn)

    data['emails_periodo'] = pd.read_sql_query(
        f"SELECT COUNT(*) as c FROM envios WHERE tipo='email' AND data_envio >= date('now', '-{days} days')",
        conn)['c'][0]
    data['whatsapp_periodo'] = pd.read_sql_query(
        f"SELECT COUNT(*) as c FROM envios WHERE tipo='whatsapp' AND data_envio >= date('now', '-{days} days')",
        conn)['c'][0]
    data['total_emails'] = pd.read_sql_query("SELECT COUNT(*) as c FROM envios WHERE tipo='email'", conn)['c'][0]
    data['total_whatsapp'] = pd.read_sql_query("SELECT COUNT(*) as c FROM envios WHERE tipo='whatsapp'", conn)['c'][0]

    data['atividade_diaria'] = pd.read_sql_query(
        f'''SELECT date(data_envio) as data, tipo, COUNT(*) as total
            FROM envios
            WHERE data_envio >= date('now', '-{days} days')
            GROUP BY date(data_envio), tipo
            ORDER BY data''', conn)

    data['leads_novos'] = pd.read_sql_query(
        f"SELECT COUNT(*) as c FROM leads WHERE data_criacao >= date('now', '-{days} days')", conn)['c'][0]

    data['envios_detalhado'] = pd.read_sql_query(
        f'''SELECT l.nome, l.empresa, l.cidade, e.tipo, e.status, e.data_envio, e.template_nome
            FROM envios e
            JOIN leads l ON e.lead_id = l.id
            WHERE e.data_envio >= date('now', '-{days} days')
            ORDER BY e.data_envio DESC''', conn)

    data['all_leads'] = pd.read_sql_query(
        "SELECT nome, empresa, email, whatsapp, cidade, segmento, status, data_criacao FROM leads ORDER BY data_criacao DESC",
        conn)

    conn.close()
    return data


def generate_excel_report(days=7):
    os.makedirs(REPORTS_DIR, exist_ok=True)
    data = get_report_data(days)

    if data is None:
        return None

    wb = Workbook()

    # ── SHEET 1: RESUMO ──────────────────────────────────────────────────────
    ws = wb.active
    ws.title = "Resumo"
    ws.sheet_view.showGridLines = False

    # Title
    ws.merge_cells("A1:G1")
    t = ws["A1"]
    t.value = f"RELATÓRIO DE PROSPECÇÃO — ÚLTIMOS {days} DIAS"
    t.font = Font(name="Arial", bold=True, size=15, color=WHITE)
    t.fill = PatternFill("solid", fgColor=BLUE_DARK)
    t.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("A2:G2")
    s = ws["A2"]
    s.value = f"Gerado em {datetime.now().strftime('%d/%m/%Y às %H:%M')}  |  Florense"
    s.font = Font(name="Arial", size=10, italic=True, color="888888")
    s.alignment = Alignment(horizontal="center")
    ws.row_dimensions[2].height = 20

    # KPI row label
    ws.merge_cells("A4:G4")
    kl = ws["A4"]
    kl.value = "MÉTRICAS DO PERÍODO"
    kl.font = Font(name="Arial", bold=True, size=11, color=BLUE_DARK)
    kl.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[4].height = 22

    kpis = [
        ("Leads Totais", data['total_leads'], BLUE_DARK),
        ("Leads Novos", data['leads_novos'], BLUE_MID),
        ("E-mails Enviados", data['emails_periodo'], "1565C0"),
        ("WhatsApp Enviados", data['whatsapp_periodo'], "00897B"),
        ("Total de Contatos", data['emails_periodo'] + data['whatsapp_periodo'], ORANGE),
    ]

    ws.row_dimensions[5].height = 28
    ws.row_dimensions[6].height = 45

    for i, (label, val, color) in enumerate(kpis):
        _kpi_block(ws, 5, i + 1, label, val, color)

    # Status breakdown
    ws.merge_cells("A8:C8")
    sl = ws["A8"]
    sl.value = "LEADS POR STATUS"
    sl.font = Font(name="Arial", bold=True, size=11, color=BLUE_DARK)
    sl.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[8].height = 22

    for j, h in enumerate(["Status", "Qtd", "% Total"]):
        c = ws.cell(row=9, column=j + 1)
        _header_style(c)
        c.value = h
    ws.row_dimensions[9].height = 20

    total = max(data['total_leads'], 1)
    for idx, row in data['por_status'].iterrows():
        r = 10 + idx
        _data_cell(ws.cell(row=r, column=1), row['status'])
        _data_cell(ws.cell(row=r, column=2), int(row['count']), center=True)
        _data_cell(ws.cell(row=r, column=3), f"{round(int(row['count']) / total * 100, 1)}%", center=True)
        ws.row_dimensions[r].height = 18

    # Segment breakdown
    if not data['por_segmento'].empty:
        seg_start_col = 5
        ws.merge_cells(f"{get_column_letter(seg_start_col)}8:{get_column_letter(seg_start_col + 2)}8")
        seg_label = ws.cell(row=8, column=seg_start_col)
        seg_label.value = "LEADS POR SEGMENTO"
        seg_label.font = Font(name="Arial", bold=True, size=11, color=BLUE_DARK)
        seg_label.alignment = Alignment(horizontal="left")

        for j, h in enumerate(["Segmento", "Qtd", "% Total"]):
            c = ws.cell(row=9, column=seg_start_col + j)
            _header_style(c)
            c.value = h

        for idx, row in data['por_segmento'].iterrows():
            r = 10 + idx
            _data_cell(ws.cell(row=r, column=seg_start_col), row['segmento'])
            _data_cell(ws.cell(row=r, column=seg_start_col + 1), int(row['count']), center=True)
            _data_cell(ws.cell(row=r, column=seg_start_col + 2),
                       f"{round(int(row['count']) / total * 100, 1)}%", center=True)

    # Column widths
    for col, width in zip("ABCDEFG", [22, 10, 10, 5, 25, 10, 10]):
        ws.column_dimensions[col].width = width

    # ── SHEET 2: LEADS ───────────────────────────────────────────────────────
    ws2 = wb.create_sheet("Todos os Leads")
    ws2.sheet_view.showGridLines = False

    ws2.merge_cells("A1:H1")
    t2 = ws2["A1"]
    t2.value = "LISTA COMPLETA DE LEADS"
    t2.font = Font(name="Arial", bold=True, size=13, color=WHITE)
    t2.fill = PatternFill("solid", fgColor=BLUE_DARK)
    t2.alignment = Alignment(horizontal="center", vertical="center")
    ws2.row_dimensions[1].height = 30

    headers2 = ["Nome", "Empresa", "E-mail", "WhatsApp", "Cidade", "Segmento", "Status", "Data de Criação"]
    for j, h in enumerate(headers2):
        c = ws2.cell(row=2, column=j + 1)
        _header_style(c)
        c.value = h
    ws2.row_dimensions[2].height = 20

    for ridx, row in data['all_leads'].iterrows():
        for cidx, val in enumerate(row):
            c = ws2.cell(row=3 + ridx, column=cidx + 1)
            _data_cell(c, str(val) if pd.notna(val) and val else "")
        ws2.row_dimensions[3 + ridx].height = 17

    for col, width in zip("ABCDEFGH", [25, 25, 30, 15, 15, 20, 18, 20]):
        ws2.column_dimensions[col].width = width

    # ── SHEET 3: ENVIOS ──────────────────────────────────────────────────────
    ws3 = wb.create_sheet("Histórico de Envios")
    ws3.sheet_view.showGridLines = False

    ws3.merge_cells("A1:G1")
    t3 = ws3["A1"]
    t3.value = f"HISTÓRICO DE ENVIOS — ÚLTIMOS {days} DIAS"
    t3.font = Font(name="Arial", bold=True, size=13, color=WHITE)
    t3.fill = PatternFill("solid", fgColor=BLUE_DARK)
    t3.alignment = Alignment(horizontal="center", vertical="center")
    ws3.row_dimensions[1].height = 30

    headers3 = ["Nome", "Empresa", "Cidade", "Tipo", "Status", "Data de Envio", "Template"]
    for j, h in enumerate(headers3):
        c = ws3.cell(row=2, column=j + 1)
        _header_style(c)
        c.value = h
    ws3.row_dimensions[2].height = 20

    for ridx, row in data['envios_detalhado'].iterrows():
        for cidx, val in enumerate(row):
            c = ws3.cell(row=3 + ridx, column=cidx + 1)
            _data_cell(c, str(val) if pd.notna(val) and val else "")
        ws3.row_dimensions[3 + ridx].height = 17

    for col, width in zip("ABCDEFG", [25, 25, 15, 12, 12, 20, 25]):
        ws3.column_dimensions[col].width = width

    filename = f"relatorio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    filepath = os.path.join(REPORTS_DIR, filename)
    wb.save(filepath)
    return filepath
