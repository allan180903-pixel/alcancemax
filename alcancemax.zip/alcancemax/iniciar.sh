#!/bin/bash
cd "$(dirname "$0")"

PORT=8501

# Se já está rodando, apenas abre o navegador na aba existente
if lsof -i :$PORT -sTCP:LISTEN &>/dev/null; then
    echo "AlcanceMax já está rodando. Abrindo no navegador..."
    open "http://localhost:$PORT"
    exit 0
fi

# Mata qualquer instância travada
pkill -f "streamlit run app.py" 2>/dev/null
sleep 1

# Instala dependências se necessário
pip3 install -q -r requirements.txt

# Inicia em background (headless = não abre aba sozinho)
echo "Iniciando AlcanceMax..."
nohup python3 -m streamlit run app.py \
  --server.headless true \
  --browser.gatherUsageStats false \
  --server.port $PORT > /tmp/alcancemax.log 2>&1 &

# Aguarda o servidor estar pronto
echo "Aguardando servidor..."
for i in {1..30}; do
    if curl -s "http://localhost:$PORT" > /dev/null 2>&1; then
        break
    fi
    sleep 0.5
done

# Abre UMA aba no navegador
open "http://localhost:$PORT"
echo "AlcanceMax aberto!"
